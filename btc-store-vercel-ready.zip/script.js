const menu=document.getElementById('menuBtn');
const closeBtn=document.getElementById('closeBtn');
const side=document.getElementById('sideMenu');
menu.onclick=()=>side.classList.add('open');
closeBtn.onclick=()=>side.classList.remove('open');